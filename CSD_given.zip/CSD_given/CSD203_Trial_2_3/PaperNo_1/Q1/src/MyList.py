from Car import *
from Node import *
class MyList:
    def __init__(self):
        self.head = None
        self.tail = None
    def isEmpty(self):
        return self.head ==None
    def traverse(self):
        pt = self.head
        while pt:
            print(pt.data, end = " ")
            pt = pt.next
        print("")        
    def clear(self):
        self.head = None
#Q1-1
    def addLast(self, name="", price=-1):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
        if name[-1] == 'B' or price > 100:
            return
        n = Node(Car(name, price))
        if (self.isEmpty()):
            self.head = n
            self.tail = n
              


        pass
    # end def
#Q1-2    
    def addFirst(self, name="", price=-1):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
        new_node = Node(Car(name,price))
        new_node.next = self.head
        self.head = new node
        curr = self.head
        while curr.next:
            curr = curr.next
        self.tail = curr





        pass
    # end def
#Q1-3
    def delete(self, price =0):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
        current = self.head
        prev = Node
        while current:
            if price == 5:
                if prev:
                    prev.next = current.next
                else:
                    self.head = current.next
                break
            prev = current
            current = current.next




        pass 
    #end def
# Q1-4
    def sort(self):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
        if self.head is None:
            return
        sorted_list = None
        current = self.head
        while current is not None:
            next_Node = current.next
            if sorted_list is None or current.data.Price < sorted_list.data.Price:
                current.next = sorted_list
                sorted_list = current
            else:
                search = sorted_list
                while search.next is not None and current.data.Price > search.next.data.Price:
                    search = search.next
                current.next = current
                search.next = current
            current = next_node
        self.head = sorted_list



        
         pass
    #end def    